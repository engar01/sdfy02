import random


class Cat:
    def __init__(self, name=None, home=None):
        self.name = name
        self.home = Bed

        self.gladness = 50  # Щастя
        self.satiety = 50  # Ситість

    def get_bed(self):
        self.get_bed()

    def to_sleep(self):
        print('zzzzzz')
        self.gladness += Bed(bed_list=brands_of_bed).comfort

    def eat(self):
        self.satiety += 5
        if self.satiety > 100:
            self.satiety = 100

    def is_alive(self):
        if self.gladness < 0:
            print('Depression.')
            return False
        if self.satiety < 0:
            print('Dead...')
            return False

    def live(self, day):
        day = f'Today the day {day} of {self.name} live!'
        print(f'{day:=^50}')
        print(f'{self.name} indexes:')
        print(f'gladness - {self.gladness} ')
        print(F'cuteness = {self.satiety}')
        if self.satiety <= 50:
            self.eat()
        if self.gladness <= 10:
            self.to_sleep()
        live_cube = random.randint(1, 2)
        if live_cube == 1:
            self.to_sleep()
        elif live_cube == 2:
            self.eat()
        self.satiety -= 5
        return self.is_alive()



class Bed:
    def __init__(self, bed_list):
        self.bed = random.choice(list(bed_list))
        self.softness = bed_list[self.bed]['softness']
        self.comfort = bed_list[self.bed]['comfort']


brands_of_bed = {
    'Pink bad': {
        'comfort': 5,
        'softness': 10
    },
    'Purple bad': {
        'comfort': 30,
        'softness': 40
    },
    'Red bad': {
        'comfort': 50,
        'softness': 70
    },
    'Orange bad': {
        'comfort': 70,
        'softness': 100
    }
}

Kasper = Cat(name='Kasper')

for day in range(1, 366):
    if Kasper.live(day) == False:
        print('Game over!')
        break